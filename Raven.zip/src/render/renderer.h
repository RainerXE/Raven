/**
 * Raven - render/renderer.h
 * Bridge between the UI thread and the rendering backend.
 *
 * Every backend call is turned into a command and executed, in submission
 * order, by a dedicated render thread. The UI thread never waits for the GPU
 * except for back-pressure: it will not queue more than a couple of frames
 * per window. When the render thread is disabled, commands run inline.
 *
 *      UI thread                               render thread
 *   paint -> frame packet --+
 *   texture create/update --+--> queue --> backend (Vulkan) --> present
 *   surface create/destroy -+
 */

#ifndef RVN_RENDERER_H
#define RVN_RENDERER_H

#include "draw.h"
#include "../core/thread.h"

/* ---------------------------------------------------------------------------
 *  Textures (render/texture.c): UI-thread description of a GPU texture
 * ------------------------------------------------------------------------- */

typedef struct rvn_texture_t {
	Rid id;
	int width, height;
	RTextureFormat format;
	RFilterType filter;
	/** 1 once the pixels were handed to the renderer, or decoding failed. */
	rvn_atomic_t ready;
	/** R_TRUE while the backend texture exists. */
	int created;
	/** Created by a backend-specific function (wrapped image view, shared memory). */
	int external;
} rvn_texture_t;

rvn_texture_t* rvn_texture_get(Rid id);
/** Allocates a handle with no backend texture yet. */
rvn_texture_t* rvn_texture_register(void);
/** Creates a texture from raw pixels. Takes ownership of `pixels` (rvn_alloc'ed, may be NULL). */
Rid rvn_texture_create_raw(int width, int height, RTextureFormat format, RFilterType filter, void* pixels);
void rvn_textures_shutdown(void);

/** Decodes an image file into RGBA8 (render/image_decode.c). Free with rvn_free. */
uint8_t* rvn_image_decode(const uint8_t* data, size_t size, int* width, int* height);

/* ---------------------------------------------------------------------------
 *  Renderer (render/renderer.c)
 * ------------------------------------------------------------------------- */

int  rvn_renderer_init(const RBackendVTable* backend, const RBackendInitInfo* info, int threaded);
void rvn_renderer_shutdown(void);
int  rvn_renderer_is_threaded(void);
/**
 * Sets a function called every few milliseconds while the UI thread is
 * blocked on the render thread (rvn_platform_t::wait_service). NULL = none.
 * Call after rvn_renderer_init.
 */
void rvn_renderer_set_wait_service(void (*service)(void));

/** Blocks until the surface exists. */
int  rvn_renderer_create_surface(Rid window, const RNativeWindow* native, uint32_t width, uint32_t height);
/** Blocks until every queued frame of the window is rendered and the surface destroyed. */
void rvn_renderer_destroy_surface(Rid window);

/** The pixel buffers are rvn_alloc'ed; the renderer takes ownership and frees them. */
void rvn_renderer_create_texture(Rid texture, const RTextureDesc* desc, void* pixels);
void rvn_renderer_update_texture(Rid texture, uint32_t x, uint32_t y, uint32_t width, uint32_t height, void* pixels);
void rvn_renderer_set_texture_filter(Rid texture, RFilterType filter);
void rvn_renderer_destroy_texture(Rid texture);

typedef void (*rvn_render_fn)(void* arg);
/** Runs a function on the render thread, in order with the other commands. */
void rvn_renderer_call(rvn_render_fn function, void* arg, int wait);
/** Blocks until every command queued so far has been executed. */
void rvn_renderer_sync(void);

/** One frame of one window travelling from the UI thread to the render thread. */
typedef struct rvn_frame_t {
	rvn_drawlist_t list;
	RDrawData data;
	/** Optional: receives the rendered pixels. */
	RCapture* capture;
	/** Optional counters owned by the window. */
	rvn_atomic_t* frames_in_flight;
	rvn_atomic_t* render_us;
	struct rvn_frame_t* next;
} rvn_frame_t;

/** Returns an empty frame packet (recycled, so its arrays keep their capacity). */
rvn_frame_t* rvn_renderer_acquire_frame(void);
/** Blocks while `frames_in_flight` is at least `max_frames`. */
void rvn_renderer_throttle(rvn_atomic_t* frames_in_flight, int max_frames);
/** Queues the frame. `frame->data` must be filled except for the instance / command arrays. */
void rvn_renderer_submit_frame(rvn_frame_t* frame);

/* Built-in backends */
const RBackendVTable* rvn_backend_null(void);
#if defined(RAVEN_BACKEND_VULKAN_ENABLED)
const RBackendVTable* rvn_backend_vulkan(void);
#endif

#endif /* RVN_RENDERER_H */
